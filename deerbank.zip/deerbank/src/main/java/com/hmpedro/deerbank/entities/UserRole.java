package com.hmpedro.deerbank.entities;

public enum UserRole {
    CUSTOMER,
    ADMIN
}
