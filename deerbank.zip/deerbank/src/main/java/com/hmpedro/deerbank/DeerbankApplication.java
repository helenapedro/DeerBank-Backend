package com.hmpedro.deerbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeerbankApplication {
    public static void main(String[] args) {
        SpringApplication.run(DeerbankApplication.class, args);
    }
}
