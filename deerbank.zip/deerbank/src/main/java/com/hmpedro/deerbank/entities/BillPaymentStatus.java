package com.hmpedro.deerbank.entities;

public enum BillPaymentStatus {
    SCHEDULED,
    PENDING,
    EXECUTED,
    CANCELLED
}
