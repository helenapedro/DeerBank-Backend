package com.hmpedro.deerbank.entities;

public enum RecurringPaymentStatus {
    ACTIVE,
    PAUSED,
    CANCELLED
}
