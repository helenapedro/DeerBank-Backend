package com.hmpedro.deerbank.entities;

public enum PaymentType {
    ONE_TIME,
    RECURRING
}
