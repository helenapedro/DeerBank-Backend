package com.hmpedro.deerbank.entities;

public enum TransactionType {
    DEBIT,
    CREDIT,
    TRANSFER,
    BILL_PAYMENT
}
