package com.hmpedro.deerbank.entities;

public enum AccountType {
    CHECKING,
    SAVINGS
}
